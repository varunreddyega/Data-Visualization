clear all;
close all;
clc;

img = imread('Ohio_Counties_map.png');
figure('Name','Color Image'), imshow(img)
title('Color Image')

I = rgb2gray(img);
figure('Name','Gray Image'), imshow(I)
title('Gray Image')

level = graythresh(I)
BW = imbinarize(I, level);
figure('Name','Binary Image'), imshow(BW);
title('Binary Image')

[row,col]=size(BW);

population=[1310300 1243857 816684 541918 532331 429899 382378 371574 309461 232173 230514 229642 205466 204826 198627 179146 175769 167995 162927 155782 134585 130696 121099  115967 106222];
population_normalized=population/population(1);


for m=1:row
        for n=1:col
                if (n>202) && (n<225) && (m>271) && (m<284)
                    g(m,n)=population_normalized(1);
                elseif (n>329) && (n<349) && (m>81) && (m<93)
                    g(m,n)=population_normalized(2);
                elseif (n>53) && (n<71) && (m>381) && (m<395)
                    g(m,n)=population_normalized(3);
                elseif (n>349) && (n<364) && (m>127) && (m<149)
                    g(m,n)=population_normalized(4);
                elseif (n>70) && (n<86) && (m>305) && (m<325) 
                    g(m,n)=population_normalized(5);
                elseif (n>127) && (n<150) && (m>64) && (m<78)
                    g(m,n)=population_normalized(6);
                elseif (n>46) && (n<66) && (m>352) && (m<366)
                    g(m,n)=population_normalized(7);
                elseif (n>347) && (n<380) && (m>183) && (m<195) 
                    g(m,n)=population_normalized(8);
                elseif (n>286) && (n<306) && (m>112) && (m<128) 
                    g(m,n)=population_normalized(9);
                elseif (n>79) && (n<99) && (m>351) && (m<365) 
                    g(m,n)=population_normalized(10);
                elseif (n>363) && (n<374) && (m>70) && (m<75)
                    g(m,n)=population_normalized(11);
                elseif (n>412) && (n<445) && (m>138) && (m<145)
                    g(m,n)=population_normalized(12);
                elseif (n>92) && (n<104) && (m>385) && (m<400) 
                    g(m,n)=population_normalized(13);
                elseif (n>201) && (n<228) && (m>257) && (m<263) 
                    g(m,n)=population_normalized(14);  
                elseif (n>417) && (n<443) && (m>123) && (m<130) 
                    g(m,n)=population_normalized(15);
                elseif (n>316) && (n<334) && (m>122) && (m<133) 
                    g(m,n)=population_normalized(16);
                elseif (n>250) && (n<280) && (m>257) && (m<265) 
                    g(m,n)=population_normalized(17);
                elseif (n>119) && (n<138) && (m>333) && (m<338) 
                    g(m,n)=population_normalized(18);
                elseif (n>380) && (n<400) && (m>112) && (m<123) 
                    g(m,n)=population_normalized(19);
                elseif (n>237) && (n<257) && (m>302) && (m<308) 
                    g(m,n)=population_normalized(20); 
                elseif (n>135) && (n<149) && (m>302) && (m<308) 
                    g(m,n)=population_normalized(21);
                elseif (n>146) && (n<163) && (m>85) && (m<101) 
                    g(m,n)=population_normalized(22); 
                elseif (n>249) && (n<263) && (m>158) && (m<170) 
                    g(m,n)=population_normalized(23); 
                elseif (n>309) && (n<332) && (m>160) && (m<170) 
                    g(m,n)=population_normalized(24); 
                elseif (n>77) && (n<100) && (m>286) && (m<290) 
                    g(m,n)=population_normalized(25);    
                else
                    g(m,n)=0;
                end
        end
end
figure('Name','Population Fixation'),imshow(g);
title('Population Fixation')

gaussian_kernel = fspecial('gaussian', [100 100], 20);
density = imfilter(g, gaussian_kernel, 'replicate');
figure('Name','Density Map'),imshow(density,[]);
title('Density Map')

omask = heatmap_overlay( img , density, 'jet' );
figure('Name','Heat Map'),imshow(omask);
title('Heatmap for Top-25 populous counties in Ohio');
colormap(jet);
colorbar;




