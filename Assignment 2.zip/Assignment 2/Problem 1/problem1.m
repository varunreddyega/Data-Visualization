close all;
clear all;
clc;

data1 = {'Brighton & Hove', (610.000+ 855.000 + 998.000 + 2020.00);
'Chichester', 396.000 + 580.000 + 613.000 + 885.000 + 891.000 + 1449.00;
'Portsmouth', 268.000 + 390.000 + 690.000 + 834.000 + 1008.00 + 1016.00 + 1201.00;
'Southampton', 169.000 + 604.000 + 757.000 + 1567.00;
'Winchester', 524.000 + 541.000 + 806.00 + 991.00 + 1079.00 + 1661.00};

Brighton = {'Books', 610.000;
'Electronics', 855.000;
'Hardware', 998.000;
'Software', 2020.00};

Chichester = {'Home & Garden', 396.000;
'Health & Beauty', 580.000;
'Sports', 613.000;
'Software', 885.000;
'Electronics', 891.000;
'DIY', 1449.00};

Portsmouth = {'Books', 268.000;
'Home & Garden', 390.000;
'Electronics', 690.000;
'DIY', 834.000;
'Sports', 1008.00;
'Clothes', 1016.00;
'Toys & Children', 1201.00};

Southampton = {'DIY', 169.000;
'Hardware', 604.000;
'Electronics', 757.000;
'Sports', 1567.00};

Winchester = {'Hardware', 524.000;
'Sports', 541.000;
'Books', 806.00;
'Software', 991.00;
'Toys & Children', 1079.00;
'Electronics', 1661.00};

stores = {Brighton, Chichester, Portsmouth, Southampton, Winchester};

% Lay out each column within that column's rectangle from the overall layout
r = treemap([data1{:,2}]);

for i = 1:5
    data = stores(i);
    m = length(data{1,1})
    colors = (3*repmat(rand(1,3),m,1) + rand(m,3))/4;
    
    rNew = treemap([data{1,1}{:,2}],r(3,i),r(4,i));
    rNew(1,:) = rNew(1,:) + r(1,i);
    rNew(2,:) = rNew(2,:) + r(2,i);
    
    labels = data{1,1}(:,1);
   
    plotRectangles(rNew,labels,colors);
end

outline(r)

legend('Brighton & Hove', 'Chichester', 'Portsmouth', 'Southampton', 'Winchester', 'Location', 'eastoutside');
      
title('Sales by Branch');


