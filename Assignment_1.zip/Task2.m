clear;
close all;
clc;

Players = {'Antoine Griezmann', 'Artem Dzyuba', 'Cristiano Ronaldo', 'Denis Cheryshev', 'Diego Costa', 'Eden Hazard', 'Edinson Cavani', 'Harry Kane', 'Ivan Perisic', 'Junior Neymar', 'Kylian Mbappe-Lottin', 'Luis Su�rez', 'Luka Modric', 'Mario Mandzukic', 'Mohamed Salah', 'Philippe Coutinho', 'Romelu Lukaku', 'Takashi Inui', 'Wahbi Khazri', 'Yerry Mina'};
Goals = [4, 3, 4, 4, 3, 3, 3, 6, 3, 2, 4, 2, 2, 3, 2, 2, 4, 2, 2, 3];
Assists = [3, 2, 0, 0, 0, 2, 0, 0, 1, 2, 0, 1, 1, 1, 0, 2, 1, 1, 2, 0];
MinutesPlayed = [575, 340, 360, 316, 323, 521, 345, 576, 638, 450, 538, 450, 606, 621, 180, 436, 481, 295, 267, 300];

% Calculate Points Value for players
Points = ((Goals.*500)+ (Assists.*250))./MinutesPlayed;
% sort the values
[sd,r]=sort(Points,'descend');

% Retrieve data for top 10 players
for i=1:10
   a=r(i);
   b=sd(i);
   sd1(i)=b;
   r1(i)=a;

   Goals1(i)=Goals(a);
   Minutes_Played1(i)=MinutesPlayed(a);
   Players1(i) = Players(a);
end

% Plotting the bar chart
chart_title = ' Top 10 Soccer Players Performance Ranking of World Cup 2018';
data = [sd1; Minutes_Played1./100; Goals1]';
bar(data);

box off
legend('Point Value','Minutes Played in hundreds', 'Goals');
set(gca, 'XTickLabel', Players1);
title(chart_title);

ylabel('Point Value');
ylim([0 8]);
h = gca;
h.XTickLabelRotation = 60;
